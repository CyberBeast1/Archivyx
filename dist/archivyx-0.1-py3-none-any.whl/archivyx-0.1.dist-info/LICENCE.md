MIT License

Copyright (c) 2025 Cyber

Permission is hereby granted, free of charge, to any person obtaining a copy of this software...
